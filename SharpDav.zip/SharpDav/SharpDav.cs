﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.ServiceProcess;
namespace SharpDav
{
    [StructLayout(LayoutKind.Explicit, Size = 16)]
    public class EVENT_DESCRIPTOR
    {
        [FieldOffset(0)]
        ushort Id = 1;
        [FieldOffset(2)]
        byte Version = 0;
        [FieldOffset(3)]
        byte Channel = 0;
        [FieldOffset(4)]
        byte Level = 4;
        [FieldOffset(5)]
        byte Opcode = 0;
        [FieldOffset(6)]
        ushort Task = 0;
        [FieldOffset(8)]
        long Keyword = 0;
    }

    [StructLayout(LayoutKind.Explicit, Size = 16)]
    public struct EventData
    {
        [FieldOffset(0)]
        internal UInt16 DataPointer;
        [FieldOffset(8)]
        internal uint Size;
        [FieldOffset(12)]
        internal int Reserved;
    }

    class SharpDav
    {
        static void Main(string[] args)
        {
            if (args[0] == "start")
            {
                StartService("webclient", 3000000);
            }
            else if (args[0] == "stop")
            {
                StopService("webclient", 3000000);
            }
            else if (args[0] == "restart")
            {
                RestartService("webclient", 3000000);
            }
            else if (args[0] == "status")
            {
                Status("webclient", 3000000);
            }
            else if (args[0] == "trigger")
            {
                Trigger();
            }
            else if (args[0] == "stop2")
            {
                Trigger2();
            }
        }
        public static void StartService(string serviceName, int timeoutMilliseconds)
        {
            ServiceController service = new ServiceController(serviceName);
            try
            {
                int millisec1 = 0;
                TimeSpan timeout;

                // count the rest of the timeout
                int millisec2 = Environment.TickCount;
                timeout = TimeSpan.FromMilliseconds(timeoutMilliseconds - (millisec1));
                Console.WriteLine("[*] Starting the Webclient");
                service.Start();
                service.WaitForStatus(ServiceControllerStatus.Running, timeout);
                Console.WriteLine("[*] Webclient started");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public static void StopService(string serviceName, int timeoutMilliseconds)
        {
            ServiceController service = new ServiceController(serviceName);
            try
            {
                int millisec1 = 0;
                TimeSpan timeout;
                if (service.Status == ServiceControllerStatus.Running)
                {
                    millisec1 = Environment.TickCount;
                    timeout = TimeSpan.FromMilliseconds(timeoutMilliseconds);
                    Console.WriteLine("[*] Stopping the Webclient");
                    service.Stop();
                    service.WaitForStatus(ServiceControllerStatus.Stopped, timeout);
                    Console.WriteLine("[*] Webclient stopped");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public static void RestartService(string serviceName, int timeoutMilliseconds)
        {
            ServiceController service = new ServiceController(serviceName);
            try
            {
                int millisec1 = 0;
                TimeSpan timeout;
                if (service.Status == ServiceControllerStatus.Running)
                {
                    millisec1 = Environment.TickCount;
                    timeout = TimeSpan.FromMilliseconds(timeoutMilliseconds);
                    Console.WriteLine("[*] Stopping the Webclient");
                    service.Stop();
                    service.WaitForStatus(ServiceControllerStatus.Stopped, timeout);
                }
                // count the rest of the timeout
                int millisec2 = Environment.TickCount;
                timeout = TimeSpan.FromMilliseconds(timeoutMilliseconds - (millisec2 - millisec1));
                Console.WriteLine("[*] Restarting the Webclient");
                service.Start();
                service.WaitForStatus(ServiceControllerStatus.Running, timeout);
                Console.WriteLine("[*] Webclient restarted");

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public static void Status(string serviceName, int timeoutMilliseconds)
        {
            ServiceController service = new ServiceController(serviceName);
            try
            {
                int millisec1 = 0;
                TimeSpan timeout;

                // count the rest of the timeout
                int millisec2 = Environment.TickCount;
                timeout = TimeSpan.FromMilliseconds(timeoutMilliseconds - (millisec1));
                Console.WriteLine("[*] Checking Webclient Status");

                //service.WaitForStatus(ServiceControllerStatus.Running, timeout);
                Console.WriteLine("[*] The status is: " + service.Status);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public static void Trigger()
        {
            [DllImport("Advapi32.dll", SetLastError = true)]
            static extern uint EventRegister(ref Guid guid, IntPtr EnableCallback, IntPtr CallbackContext, ref long RegHandle);

            [DllImport("Advapi32.dll", SetLastError = true)]
            static extern unsafe uint EventWrite(long RegHandle, ref EVENT_DESCRIPTOR EventDescriptor, uint UserDataCount, EventData* UserData);

            [DllImport("Advapi32.dll", SetLastError = true)]
            static extern uint EventUnregister(long RegHandle);

            try
            {

                Guid WebClientTrigger = new Guid(0x22B6D684, 0xFA63, 0x4578, 0x87, 0xC9, 0xEF, 0xFC, 0xBE, 0x66, 0x43, 0xC7);
                long RegistrationHandle = 0;

                if (EventRegister(ref WebClientTrigger, IntPtr.Zero, IntPtr.Zero, ref RegistrationHandle) == 0)
                {
                    EVENT_DESCRIPTOR EventDescriptor = new EVENT_DESCRIPTOR();

                    unsafe
                    {
                        EventWrite(RegistrationHandle, ref EventDescriptor, 0, null);
                        EventUnregister(RegistrationHandle);
                    }

                    Console.WriteLine("[*] Webclient should be started now");

                } }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public static void Trigger2()
        {
            [DllImport("Advapi32.dll", SetLastError = true)]
            static extern uint EventRegister(ref Guid guid, IntPtr EnableCallback, IntPtr CallbackContext, ref long RegHandle);

            [DllImport("Advapi32.dll", SetLastError = true)]
            static extern unsafe uint EventWrite(long RegHandle, ref EVENT_DESCRIPTOR EventDescriptor, uint UserDataCount, EventData* UserData);

            [DllImport("Advapi32.dll", SetLastError = true)]
            static extern uint EventUnregister(long RegHandle);

            try
            {

                Guid WebClientTrigger = new Guid(0x22B6D684, 0xFA63, 0x4578, 0x87, 0xC9, 0xEF, 0xFC, 0xBE, 0x66, 0x43, 0xC7);
                long RegistrationHandle = 0;

                if (EventRegister(ref WebClientTrigger, IntPtr.Zero, IntPtr.Zero, ref RegistrationHandle) == 0)
                {
                    EVENT_DESCRIPTOR EventDescriptor = new EVENT_DESCRIPTOR();

                    unsafe
                    {
                        EventWrite(RegistrationHandle, ref EventDescriptor, 1, null);
                        EventUnregister(RegistrationHandle);
                    }

                    Console.WriteLine("[*] Webclient should be stopped now");

                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}

